# visual-search-kk

katie khamsoda; fardosa ali

The experiment is done by paired simultaneous participants.

- [ ] The experiment starts by asking which member of the pair the current participant is, 'a' or 'b'.
- [ ] If they are 'a', they get '^^' feedback on 8 out of the 10 trials that do have feedback, '==' on the other 2
- [ ] If they are 'b', they get 'vv' feedback on 8 out of the 10 trials that do have feedback, '==' on the other 2

Procedure

- [ ] 100 trials total: 5 blocks of 20 trials
- [ ] search task is on for 2 seconds, with no response possible
- [ ] white screen with fixation dot until keyboard response indicating whether target was present (z) or absent (m)
- [ ] at the end of every 10th trial, give feedback: 10 feedback trials in total (with fixed feedback, as described above)
- [ ] participant tells experimenter what the feedback was
- [ ] any key to continue
- [ ] at the end of each of 5 blocks of 20 trials, get a likert scale confidence rating "on their performance": 1 = not confident; 7 = very confident

We've also got the main task to set up which is a visual search task using a database of 80-85 images and specific responses to give to each, but I'm happy to come in and work on that once uni is open again.
