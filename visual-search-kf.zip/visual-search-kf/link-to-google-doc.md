https://docs.google.com/document/d/1lseMOwzs7aDsjvmqv6eiTiuvlFLoWxW0pEb8Wp99q_8/edit?ts=5a9ec8a7
